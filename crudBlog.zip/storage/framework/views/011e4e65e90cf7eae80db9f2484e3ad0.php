<!DOCTYPE html>
<html lang="es">

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BLOGGER</title>
</head>

<body>
    <table>
        <thead>
            <tr>
                <th>
                    ID
                </th>
                <th>
                    Nombre
                </th>
                <th>
                    Contenido
                </th>
                <th>
                    Categoría
                </th>
                <th>
                    Autor
                </th>
                <?php if(auth()->check()): ?>
                    <?php if(auth()->user()->role == 'admin'): ?>
                        <th>
                            Editar
                        </th>
                        <th>
                            Borrar
                        </th>
                    <?php endif; ?>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if(isset($posts)): ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($p->id); ?>

                        </td>
                        <td>
                            <?php echo e($p->nombre); ?>

                        </td>
                        <td>
                            <?php echo e($p->contenido); ?>

                        </td>
                        <td>
                            <?php echo e($p->id_categoria); ?>

                        </td>
                        <td>
                            <?php echo e($p->id_autor); ?>

                        </td>
                        <?php if(auth()->check()): ?>
                            <?php if(auth()->user()->role == 'admin'): ?>
                                <td>
                                    <form action="/editarPost" method="GET">
                                        <input type="text" id="id" name="id" value="<?php echo e($p->id); ?>"
                                            style="display: none" />
                                        <input type="text" id="nombre" name="nombre" value="<?php echo e($p->nombre); ?>"
                                            style="display: none" />
                                        <input type="text" id="contenido" name="contenido" value="<?php echo e($p->contenido); ?>"
                                            style="display: none" />
                                        <button type="submit">Editar</button>
                                    </form>
                                </td>
                                <td>
                                    <form action="/postDelete">
                                        <input type="text" id="id" name="id" value="<?php echo e($p->id); ?>"
                                            style="display: none" />
                                        <button type="submit">Borrar</button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
    <?php if(auth()->check()): ?>
        <?php if(auth()->user()->role == 'admin'): ?>
            <form action="añadirPost">
                <button type="submit">Añadir post</button>
            </form>
            <form action="admin">
                <button type="submit">Volver</button>
            </form>
        <?php else: ?>
            <form action="/">
                <button type="submit">Volver</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
</body>

</html>
<?php /**PATH C:\wamp64\www\prueba-practicas-crud-blog\crud-blog\resources\views/verPosts.blade.php ENDPATH**/ ?>