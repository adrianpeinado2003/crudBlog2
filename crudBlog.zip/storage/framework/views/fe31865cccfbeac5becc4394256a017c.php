<!DOCTYPE html>
<html lang="es">

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BLOGGER</title>
</head>

<body>
    <form action="postView">
        <?php echo csrf_field(); ?>
        <button type="submit">Posts</button>
    </form>
    <form action="categoriaView">
        <?php echo csrf_field(); ?>
        <button type="submit">Categorías</button>
    </form>
    <form action="userView">
        <?php echo csrf_field(); ?>
        <button type="submit">Usuarios</button>
    </form>
</body>

</html>
<?php /**PATH C:\wamp64\www\prueba-practicas-crud-blog\crud-blog\resources\views/panelControl.blade.php ENDPATH**/ ?>