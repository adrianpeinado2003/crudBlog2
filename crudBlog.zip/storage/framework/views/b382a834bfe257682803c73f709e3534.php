<!DOCTYPE html>
<html lang="es">

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BLOGGER</title>
</head>

<body>
    <table>
        <thead>
            <tr>
                <th>
                    ID
                </th>
                <th>
                    Nombre
                </th>
                <th>
                    Editar
                </th>
                <th>
                    Borrar
                </th>
            </tr>
        </thead>
        <tbody>
            <?php if(isset($categoria)): ?>
                <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($c->id); ?>

                        </td>
                        <td>
                            <?php echo e($c->nombre); ?>

                        </td>
                        <td>
                            <form action="/editarCategoria" method="GET">
                                <input type="text" id="id" name="id" value="<?php echo e($c->id); ?>" style="display: none" />
                                <button type="submit">Editar</button>
                            </form>
                        </td>
                        <td>
                            <form action="/categoriaDelete">
                                <input type="text" id="id" name="id" value="<?php echo e($c->id); ?>" style="display: none" />
                                <button type="submit">Borrar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\wamp64\www\prueba-practicas-crud-blog\crud-blog\resources\views//verCategorias.blade.php ENDPATH**/ ?>