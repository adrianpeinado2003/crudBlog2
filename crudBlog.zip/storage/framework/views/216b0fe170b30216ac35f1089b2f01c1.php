<!DOCTYPE html>
<html lang="es">

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BLOGGER</title>
</head>

<body>
    <?php if(auth()->check()): ?>
        <table>
            <thead>
                <tr>
                    <th>
                        ID
                    </th>
                    <th>
                        Nombre
                    </th>
                    <th>
                        Ver posts
                    </th>
                    <?php if(auth()->check()): ?>
                        <?php if(auth()->user()->role == 'admin'): ?>
                            <th>
                                Editar
                            </th>
                            <th>
                                Borrar
                            </th>
                        <?php endif; ?>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if(isset($categorias)): ?>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($c->id); ?>

                            </td>
                            <td>
                                <?php echo e($c->nombre); ?>

                            </td>
                            <td>
                                <form action="/verPostsCategoria">
                                    <input type="text" id="id" name="id" value="<?php echo e($c->id); ?>"
                                        style="display: none" />
                                    <button type="submit">Ver posts</button>
                                </form>
                            </td>
                            <?php if(auth()->check()): ?>
                                <?php if(auth()->user()->role == 'admin'): ?>
                                    <td>
                                        <form action="/editarCategoria" method="GET">
                                            <input type="text" id="id" name="id" value="<?php echo e($c->id); ?>"
                                                style="display: none" />
                                            <input type="text" id="nombre" name="nombre" value="<?php echo e($c->nombre); ?>"
                                                style="display: none" />
                                            <button type="submit">Editar</button>
                                        </form>
                                    </td>
                                    <td>
                                        <form action="/categoriaDelete">
                                            <input type="text" id="id" name="id" value="<?php echo e($c->id); ?>"
                                                style="display: none" />
                                            <button type="submit">Borrar</button>
                                        </form>
                                    </td>
                                <?php endif; ?>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
        <?php if(auth()->check()): ?>
            <?php if(auth()->user()->role == 'admin'): ?>
                <form action="añadirCategoria">
                    <button type="submit">Añadir categoría</button>
                </form>
                <form action="admin">
                    <button type="submit">Volver</button>
                </form>
            <?php else: ?>
                <form action="/">
                    <button type="submit">Volver</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    <?php else: ?>
        <form action="login">
            <?php echo csrf_field(); ?>
            <button type="submit">Iniciar sesión</button>
        </form>
        <form action="register">
            <?php echo csrf_field(); ?>
            <button type="submit">Registrarse</button>
        </form>
    <?php endif; ?>
</body>

</html>
<?php /**PATH C:\wamp64\www\prueba-practicas-crud-blog\crud-blog\resources\views/verCategorias.blade.php ENDPATH**/ ?>