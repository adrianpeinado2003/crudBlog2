<?php $__env->startSection('contenido'); ?>
    <img src="img/logo.jpg" alt="" width="50%" height="50%">
    <?php if(Auth::check()): ?>
        <div class="nav-link text-gray-500 hover:text-gray-700 focus:text-gray-700 p-0">
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                Cerrar sesión
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </div>
        <form action="editarPerfil">
            <?php echo csrf_field(); ?>
            <button type="submit">Editar perfil</button>
        </form>
        <form action="postView">
            <?php echo csrf_field(); ?>
            <button type="submit">Ver posts</button>
        </form>
        <form action="categoriaView">
            <?php echo csrf_field(); ?>
            <button type="submit">Ver categorías</button>
        </form>
        <form action="userView">
            <?php echo csrf_field(); ?>
            <button type="submit">Ver usuarios</button>
        </form>
    <?php else: ?>
        <form action="login">
            <?php echo csrf_field(); ?>
            <button type="submit">Iniciar sesión</button>
        </form>
        <form action="register">
            <?php echo csrf_field(); ?>
            <button type="submit">Registrarse</button>
        </form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\prueba-practicas-crud-blog\crud-blog\resources\views/index.blade.php ENDPATH**/ ?>