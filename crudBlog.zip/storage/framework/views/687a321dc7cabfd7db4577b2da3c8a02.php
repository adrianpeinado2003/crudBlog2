<!DOCTYPE html>
<html lang="es">

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BLOGGER</title>
</head>

<body>
    <table>
        <thead>
            <tr>
                <th>
                    ID
                </th>
                <th>
                    Nombre
                </th>
                <th>
                    Email
                </th>
                <?php if(auth()->check()): ?>
                    <?php if(auth()->user()->role == 'admin'): ?>
                        <th>
                            Editar
                        </th>
                        <th>
                            Borrar
                        </th>
                    <?php endif; ?>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php if(isset($users)): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($u->id); ?>

                        </td>
                        <td>
                            <?php echo e($u->name); ?>

                        </td>
                        <td>
                            <?php echo e($u->email); ?>

                        </td>
                        <?php if(auth()->check()): ?>
                            <?php if(auth()->user()->role == 'admin'): ?>
                                <td>
                                    <form action="/editarUsuarios" method="GET">
                                        <input type="text" id="id" name="id" value="<?php echo e($u->id); ?>"
                                            style="display: none" />
                                        <input type="text" id="name" name="name" value="<?php echo e($u->name); ?>"
                                            style="display: none" />
                                        <input type="text" id="email" name="email" value="<?php echo e($u->email); ?>"
                                            style="display: none" />
                                        <button type="submit">Editar</button>
                                    </form>
                                </td>
                                <td>
                                    <form action="/userDeleteFromAdmin">
                                        <input type="text" id="id" name="id" value="<?php echo e($u->id); ?>"
                                            style="display: none" />
                                        <button type="submit">Borrar</button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
    <?php if(auth()->check()): ?>
        <?php if(auth()->user()->role == 'admin'): ?>
            <form action="añadirUsuarios">
                <button type="submit">Añadir usuario</button>
            </form>
            <form action="admin">
                <button type="submit">Volver</button>
            </form>
        <?php else: ?>
            <form action="/">
                <button type="submit">Volver</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
</body>

</html>
<?php /**PATH C:\wamp64\www\prueba-practicas-crud-blog\crud-blog\resources\views//verUsuarios.blade.php ENDPATH**/ ?>