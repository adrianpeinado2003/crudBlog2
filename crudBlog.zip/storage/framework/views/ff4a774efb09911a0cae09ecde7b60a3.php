<!DOCTYPE html>
<html lang="es">

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BLOGGER</title>
</head>

<body>
    <h1>Editar Post</h1>
    <br>
    <form action="/postEdit">
        <?php echo csrf_field(); ?>
        <input type="text" id="id" name="id" value="<?php echo e($_GET['id']); ?>" style="display: none" />
        <div>
            <label for="nombre">Nombre</label>
            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div>
                    <p style="color: red">Por favor, asigne un nombre</p>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="text" id="nombre" name="nombre" placeholder="<?php echo e($_GET['nombre']); ?>" />
        </div>
        <br>
        <div>
            <label for="nombre">Contenido</label>
            <?php $__errorArgs = ['contenido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div>
                    <p style="color: red">Por favor, desarrolle un contenido</p>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="text" id="contenido" name="contenido" placeholder="<?php echo e($_GET['contenido']); ?>" />
        </div>
        <br>
        <div>
            <label for="categoria">Categoría</label>
            <?php $__errorArgs = ['categoria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div>
                    <p style="color: red">Por favor, seleccione una categoria</p>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <select name="categoria" id="categoria">
                <?php if(isset($categorias)): ?>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c->id); ?>"><?php echo e($c->id); ?>. <?php echo e($c->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </div>
        <br>
        <button type="submit">Editar</button>
    </form>
</body>

</html>
<?php /**PATH C:\wamp64\www\prueba-practicas-crud-blog\crud-blog\resources\views/editarPost.blade.php ENDPATH**/ ?>