<!DOCTYPE html>
<html lang="es">

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BLOGGER</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>

<body>
    <header>
        <div class="navbar">
            <div class="navbar-inner">
              <ul class="nav">
                <li><a href="login">Iniciar sesión</a></li>
                <li><a href="register">Registrarse</a></li>
              </ul>
            </div>
          </div>
    </header>

    <main>
        <?php echo $__env->yieldContent('contenido'); ?>
    </main>

    <footer>

    </footer>
</body>

</html>
<?php /**PATH C:\wamp64\www\prueba-practicas-crud-blog\crud-blog\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>