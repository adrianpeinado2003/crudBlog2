<!DOCTYPE html>
<html lang="es">

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BLOGGER</title>
</head>

<body>
    <h1>Añadir Usuarios</h1>
    <br>
    <form action="/userCreate">
        <?php echo csrf_field(); ?>
        <div>
            <label for="nombre">Nombre</label>
            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div>
                    <p style="color: red">Por favor, asigne un nombre</p>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="text" id="nombre" name="nombre" />
        </div>
        <br>
        <div>
            <label for="email">Email</label>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div>
                    <p style="color: red">Por favor, asigne un email</p>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="text" id="email" name="email" />
        </div>
        <br>
        <div>
            <label for="contraseña">Contraseña</label>
            <?php $__errorArgs = ['contraseña'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div>
                    <p style="color: red">Por favor, asigne une contraseña</p>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <input type="text" id="contraseña" name="contraseña" />
        </div>
        <br>
        <button type="submit">Añadir</button>
    </form>
</body>

</html>
<?php /**PATH C:\wamp64\www\prueba-practicas-crud-blog\crud-blog\resources\views/añadirUsuarios.blade.php ENDPATH**/ ?>